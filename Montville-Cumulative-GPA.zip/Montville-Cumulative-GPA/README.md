# Montville-Cumulative-GPA
A Google Extension that can be used in the grading history tab of parent access (within the grading section) to calculate one's cumulative GPA across his/her years at MTHS.
